import pandas

fxl = pandas.read_excel("description.xlsx", sheet_name="LookupAREA")
fcsv = pandas.read_csv("data.csv")


while True:
    region = input("\nIevadiet regionu: ")

    area = fxl[fxl['Description'] == region]

    if area.empty:
        print('Wrong region')
        break
    else:
        rcode = area.iloc[0]['Area']
        
        fcsv.columns = ['anzsic06', 'Area', 'year', 'geo_count', 'ec_count']
        result = fcsv[fcsv['Area'] == rcode]['geo_count'].sum()
        
        print(f"Geo Count - {int(result)} in {region}")
    